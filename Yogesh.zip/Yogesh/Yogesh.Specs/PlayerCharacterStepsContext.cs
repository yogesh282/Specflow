﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Yogesh.Specs
{
    public class PlayerCharacterStepsContext
    {
        public PlayerCharacter Player { get; set; }

        public int StartingMagicalPower { get; set; }
    }
}
