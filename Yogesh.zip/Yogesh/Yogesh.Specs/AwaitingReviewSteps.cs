﻿using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;

namespace Yogesh.Specs
{
    [Binding]
    [Scope(Tag = "awaitingReiviewBeforeStartingWork")]
  public   class AwaitingReviewSteps
    {
        [Given(".*")]
        [Then(".*")]
        [When(".*")]

        public void Empty()
        {

        }
    }
}
