﻿using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;

namespace Yogesh.Specs
{
    [Binding]
  public  class Hooks: Steps
    {
        [BeforeScenario("elf")]
        public void BeforeScenario()
        {

        }

        [AfterScenario]
      public void AfterScenario()
        {

        } 
    }
}
