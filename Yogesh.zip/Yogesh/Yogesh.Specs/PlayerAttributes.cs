﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Yogesh.Specs
{
    class PlayerAttributes
    {
        public string Race { get; set; }

        public int Resistance { get; set; }
    }
}
