﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Yogesh
{
   public class MagicalItem
    {
        public string Name { get; set; }

        public int Value { get; set; }

        public int Power { get; set; }
    }
}
