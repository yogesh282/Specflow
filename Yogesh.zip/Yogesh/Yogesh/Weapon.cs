﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Yogesh
{
   public  class Weapon
    {
        public string Name { get; set; }

        public int Value { get; set; }
    }
}
